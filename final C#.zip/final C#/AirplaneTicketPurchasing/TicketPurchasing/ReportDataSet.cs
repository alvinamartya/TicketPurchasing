﻿namespace TicketPurchasing
{
}

namespace TicketPurchasing
{


    public partial class ReportDataSet
    {
    }
}
namespace TicketPurchasing {
    
    
    public partial class ReportDataSet {
    }
}
