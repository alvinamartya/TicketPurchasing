﻿namespace TicketPurchasing
{


    partial class TicketDataSet
    {
        partial class DataTable1DataTable
        {
        }
    }
}
